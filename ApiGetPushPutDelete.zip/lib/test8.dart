// import 'package:flutter/material.dart';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
//
// class Product {
//   int? userId;
//   int? id;
//   String? title;
//
//   Product({this.userId, this.id, this.title});
//
//   Product.fromJson(Map<String, dynamic> json) {
//     userId = json['userId'];
//     id = json['id'];
//     title = json['title'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['userId'] = this.userId;
//     data['id'] = this.id;
//     data['title'] = this.title;
//     return data;
//   }
// }
//
// void main() {
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Products List',
//       home: ProductListScreen(),
//     );
//   }
// }
//
// class ProductListScreen extends StatefulWidget {
//   @override
//   _ProductListScreenState createState() => _ProductListScreenState();
// }
//
// class _ProductListScreenState extends State<ProductListScreen> {
//   late Future<List<Product>> products;
//
//   @override
//   void initState() {
//     super.initState();
//     products = fetchProducts();
//   }
//
//   Future<List<Product>> fetchProducts() async {
//     final response =
//     await http.get(Uri.parse('https://fakestoreapi.com/products'));
//     if (response.statusCode == 200) {
//       List jsonResponse = json.decode(response.body);
//
//       print("check list length ${jsonResponse.map((data) => Product.fromJson(data)).toList().length??0}");
//       return jsonResponse.map((data) => Product.fromJson(data)).toList();
//     } else {
//       throw Exception('Failed to load products');
//     }
//   }
//
//   Future<void> postProduct() async {
//     final url = Uri.parse('https://fakestoreapi.com/products');
//     final response = await http.post(
//       url,
//       headers: {'content-type': 'application/json'},
//       body: jsonEncode({
//         'title': 'test product',
//         'userId': 2,
//       }),
//     );
//
//     if (response.statusCode == 200 || response.statusCode == 201) {
//       final jsonResponse = json.decode(response.body);
//       print('Product Posted: $jsonResponse');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Product successfully posted!')),
//       );
//
//       // Refresh the products list after posting
//       setState(() {
//         products = fetchProducts();
//       });
//     } else {
//       print('Failed to post product: ${response.statusCode}');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to post product.')),
//       );
//     }
//   }
//
//   Future updateProduct() async{
//     final response= await http.put(
//       Uri.parse('https://fakestoreapi.com/products'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: jsonEncode(<String, String>{
//         'title': "asd",
//       }),
//     );
//
//     print("checd f${response?.body}");
//   }
//
//   Future<http.Response> deleteProduct(String id) async {
//     final http.Response response = await http.delete(
//       Uri.parse('https://fakestoreapi.com/products/$id'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//     );
//     print("Delete:${response?.body}");
//     return response;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//
//         title: Text('Products List'),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.add),
//             onPressed: () {
//               postProduct();
//               //updateProduct();
//               // deleteProduct("7");
//             },
//           ),
//         ],
//       ),
//       body: FutureBuilder<List<Product>>(
//         future: products,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(child: CircularProgressIndicator());
//           } else if (snapshot.hasError) {
//             return Center(child: Text('Error: ${snapshot.error}'));
//           } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
//             return Center(child: Text('No products found'));
//           } else {
//             return ListView.builder(
//               itemCount: snapshot.data!.length,
//               itemBuilder: (context, index) {
//                 final product = snapshot.data![index];
//                 return Card(
//                   child: ListTile(
//                     title: Text('${product.title}'),
//                     subtitle: Text('${product.id}'),
//                     leading: Text('${product.userId}'),
//                   ),
//                 );
//               },
//             );
//           }
//         },
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:dio/dio.dart';

class Product {
  int? userId;
  int? id;
  String? title;

  Product({this.userId, this.id, this.title});

  Product.fromJson(Map<String, dynamic> json) {
    userId = json['userId'];
    id = json['id'];
    title = json['title'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userId'] = this.userId;
    data['id'] = this.id;
    data['title'] = this.title;
    return data;
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Products List',
      home: ProductListScreen(),
    );
  }
}

class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late Future<List<Product>> products;

  final Dio _dio = Dio(); // Create a Dio instance

  @override
  void initState() {
    super.initState();
    products = fetchProducts();
  }

  Future<List<Product>> fetchProducts() async {
    try {
      final response = await _dio.get('https://fakestoreapi.com/products');
      if (response.statusCode == 200) {
        List jsonResponse = response.data;
        return jsonResponse.map((data) => Product.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      throw Exception('Failed to load products: $e');
    }
  }

  Future<void> postProduct() async {
    try {
      final response = await _dio.post(
        'https://fakestoreapi.com/products',
        data: jsonEncode({
          'title': 'test product',
          'userId': 2,
        }),
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final jsonResponse = response.data;
        print('Product Posted: $jsonResponse');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Product successfully posted!')),
        );

        // Refresh the products list after posting
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to post product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to post product: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to post product.')),
      );
    }
  }

  Future<void> updateProduct(int productId) async {
    try {
      final response = await _dio.put(
        'https://fakestoreapi.com/products/$productId',
        data: jsonEncode({
          'title': 'Updated product title',
          'userId': 2,
        }),
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        final jsonResponse = response.data;
        print("Product updated: $jsonResponse");
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to update product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to update product: $e');
    }
  }

  Future<void> deleteProduct(int productId) async {
    try {
      final response = await _dio.delete(
        'https://fakestoreapi.com/products/$productId',
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        print("Product deleted successfully.");
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to delete product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to delete product: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products List'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              postProduct();
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Product>>(
        future: products,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No products found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final product = snapshot.data![index];
                return Card(
                  child: ListTile(
                    title: Text('${product.title}'),
                    subtitle: Text('${product.id}'),
                    leading: Text('${product.userId}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () {
                            updateProduct(product.id!);  // Pass the product id for updating
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () {
                            deleteProduct(product.id!);  // Pass the product id for deletion
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
