
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:dio/dio.dart';

class Product {
  int? userId;
  int? id;
  String? title;
  String? body;

  Product({this.userId, this.id, this.title, this.body});

  Product.fromJson(Map<String, dynamic> json) {
    userId = json['userId'];
    id = json['id'];
    title = json['title'];
    body = json['body'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userId'] = this.userId;
    data['id'] = this.id;
    data['title'] = this.title;
    data['body'] = this.body;
    return data;
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Products List',
      home: ProductListScreen(),
    );
  }
}

class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late Future<List<Product>> products;

  final Dio _dio = Dio(); // Create a Dio instance

  @override
  void initState() {
    super.initState();
    products = fetchProducts();
  }

  Future<List<Product>> fetchProducts() async {
    try {
      final response = await _dio.get('https://jsonplaceholder.typicode.com/posts');
      if (response.statusCode == 200) {
        List jsonResponse = response.data;
        return jsonResponse.map((data) => Product.fromJson(data)).toList();
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      throw Exception('Failed to load products: $e');
    }
  }

  Future<void> postProduct() async {
    try {
      final response = await _dio.post(
        'https://jsonplaceholder.typicode.com/posts',
        data: jsonEncode({
          'title': 'test product',
          'userId': 2,
          'body' : 'dhbcdhjw'
        }),
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final jsonResponse = response.data;
        print('Product Posted: $jsonResponse');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Product successfully posted!')),
        );

        // Refresh the products list after posting
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to post product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to post product: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to post product.')),
      );
    }
  }

  Future<void> updateProduct(int productId) async {
    try {
      final response = await _dio.put(
        'https://jsonplaceholder.typicode.com/posts/$productId',
        data: jsonEncode({
          'title': 'Updated product title',
          'userId': 2,
          'body' : 'dhbcdhjw'
        }),
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        final jsonResponse = response.data;
        print("Product updated: $jsonResponse");
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to update product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to update product: $e');
    }
  }

  Future<void> deleteProduct(int productId) async {
    try {
      final response = await _dio.delete(
        'https://jsonplaceholder.typicode.com/posts/$productId',
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        print("Product deleted successfully.");
        setState(() {
          products = fetchProducts();
        });
      } else {
        throw Exception('Failed to delete product: ${response.statusCode}');
      }
    } catch (e) {
      print('Failed to delete product: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products List'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              postProduct();
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Product>>(
        future: products,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No products found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final product = snapshot.data![index];
                return Card(
                  child: ListTile(
                    title: Column(
                      children: [
                        Text('${product.title}'),
                        Text('${product.body}'),
                      ],
                    ),
                    subtitle: Text('${product.id}'),
                    leading: Text('${product.userId}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () {
                            updateProduct(product.id!);  // Pass the product id for updating
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () {
                            deleteProduct(product.id!);  // Pass the product id for deletion
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}